<?php

use Illuminate\Support\Facades\Route;
use Modules\Admin\App\Http\Controllers\spatie\RolesController;
use Modules\Admin\App\Http\Controllers\auth\AdminAuthController;
use Modules\Admin\App\Http\Controllers\brand\BrandController;
use Modules\Admin\App\Http\Controllers\category\CategoryController;
use Modules\Admin\App\Http\Controllers\spatie\PermissionsController;
use Modules\Admin\App\Http\Controllers\dashboard\AdminDashboardController;
use Modules\Admin\App\Http\Controllers\product\ProductController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*==================================================================================
  *======================       Route For Admin Authintication       ===============
  *=================================================================================
*/

Route::match(['get', 'post'], '/admin-login', [AdminAuthController::class, 'adminLogin'])->name('admin_login');
Route::get('/admin-logout', [AdminAuthController::class, 'adminLogout'])->name('admin_logout');
Route::get('/admin-register', [AdminAuthController::class, 'adminRegister'])->name('admin_register');

Route::prefix('/admin')->middleware('admin')->group(function () {
    /*==================================================================================
    *======================       Route For Admin Dashboard       ====================
    *=================================================================================
  */
  Route::get('/', [AdminDashboardController::class, 'adminDashboard'])->name('admin_dashboard');
  /*==================================================================================
    *======================      Route For Categories     ====================
    *=================================================================================
  */
  Route::controller(CategoryController::class)->group(function () {
    Route::get('/add-category', 'addCategory')->name('add_category');

  });

  /*==================================================================================
    *======================      Route For Brands     ====================
    *=================================================================================
  */
  Route::controller(BrandController::class)->group(function () {
    Route::get('/add-brand-page', 'addBrandView')->name('add_brand_page');
    Route::post('/add-brand', 'addBrand')->name('add_brand');
  });
  
  /*==================================================================================
    *======================      Route For Roles Permissions      ====================
    *=================================================================================
    */
    Route::get('roles', [RolesController::class, 'index'])->name('roles.index');
    Route::post('roles/store', [RolesController::class, 'store'])->name('roles.store');
    Route::get('roles/show/{id}', [RolesController::class, 'show'])->name('roles.show');
    Route::put('roles/update/{id}', [RolesController::class, 'update'])->name('roles.update');
    Route::get('roles/destroy/{id}', [RolesController::class, 'destroy'])->name('roles.destroy');
    Route::post('role-permission/{id}', [RolesController::class, 'rolePermissionUpdate'])->name('role-permission');

  Route::get('permissions', [PermissionsController::class, 'index'])->name('permissions.index');
  Route::post('permissions', [PermissionsController::class, 'store'])->name('permissions.store');
  Route::put('permissions/{id}', [PermissionsController::class, 'update'])->name('permissions.update');
  Route::get('permissions/delete/{id}', [PermissionsController::class, 'destroy'])->name('permissions.destroy');
  
});

/*==================================================================================
*======================      Route For Products              ====================
*================================================================================
*/
Route::get('create-product',[ProductController::class,'createProduct'])->name('create_product');
Route::get('products',[ProductController::class,'allProduct'])->name('products');
