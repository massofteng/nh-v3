@php
    $title = 'Add Category';
@endphp 
@extends('admin::layouts.app')
@section('page-content')
<form action="#" method="POST" enctype="multipart/form-data">
    <div class="row">
        <div class="col-9">
            <div class="card">
                <div class="card-body">
                    <h2 class="text-center">{{ $title }}</h2>
                    <p class="sub-header text-center text-danger">
                        (Please add Logo and Banner for every category)
                    </p>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label for="simpleinput" class="form-label">Category Name<span class="text-danger">*</span>:</label>
                                <input type="text" name="" id="simpleinput" class="form-control" placeholder="Category Name">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label for="example-select" class="form-label">Parent Category:</label>
                                <div class="custom_seletct">
                                    <select name="" data-toggle="select2" class="form-control" data-width="100%">
                                        <option value="0">Select Parent Category (optional)</option>
                                        <option value="CA">California</option>
                                        <option value="NV">Nevada</option>
                                        <option value="OR">Oregon</option>
                                        <option value="WA">Washington</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="mb-3">
                                <label for="simpleinput" class="form-label">Description:</label>
                                <textarea id="textarea" class="form-control" maxlength="300" rows="5"></textarea>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label for="simpleinput" class="form-label">Logo:</label>
                                <input type="file" data-plugins="dropify" data-height="200" />
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label for="simpleinput" class="form-label">Banner:</label>
                                <input type="file" data-plugins="dropify" data-height="200" />
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-center" >
                            <div class="" style="margin-right:10px;">
                                <a href="#"
                                    class="btn btn-danger">
                                    Back
                                </a>
                            </div>
                            <div class="">
                                <button type="submit" class="btn btn-success">
                                    Add Category
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="card">
                <div class="card-body">
                    <h4 class="text-center">Others Configuration</h4>
                    <div class="row">
                        <div class="switchery-demo" style="margin-left: 10px;">
                            <span>Active Status</span>
                            <input type="checkbox" data-plugin="switchery" data-color="#47B755" data-size="small"/>
                            <input type="hidden" name="" value="0">
                        </div>
                        <div class="switchery-demo mt-3">
                            <img src="{{asset('back-end/media/images/active-inactive.jpg')}}"
                            style="height: 75px; width: auto" alt="">
                            <span class="text-muted d-flex justify-content-center">(example)</span>
                        </div>
                        <div class="switchery-demo mb-2 border-top pt-1">
                            <span>Show on home page top menu</span>
                            <input type="checkbox" data-plugin="switchery" data-color="#47B755" data-size="small" checked/>
                            <input type="hidden" name="" value="0">
                        </div>
                        <div class="switchery-demo mb-2 pt-1">
                            <img src="{{asset('back-end/media/images/homepage-top-view.jpg')}}" class="img-fluid" alt="">
                            <span class="text-muted d-flex justify-content-center">(example)</span>
                        </div>
                        <div class="switchery-demo mb-2 border-top pt-1">
                            <span>Show on home page top menu</span>
                            <span>Sidebar</span>
                            <input type="checkbox" name="" data-plugin="switchery" data-color="#47B755" data-size="small" checked/>
                            <img src="{{asset('back-end/media/images/banner-side-bar.jpg')}}" class="img-fluid mt-2" alt="">
                            <span class="text-muted d-flex justify-content-center">(example)</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
@endsection

