@extends('admin::layouts.app')
@section('page-content')
    <div class="row align-items-center">
        <div class="border-0 mb-4">
            <div
                class="card-header py-3 no-bg bg-transparent d-flex align-items-center px-0 justify-content-between border-bottom flex-wrap">
                <h3 class="fw-bold mb-0">Roles</h3>
                <div class="col-auto d-flex w-sm-100">
                    <button type="button" class="btn btn-dark btn-set-task w-sm-100" data-bs-toggle="modal"
                        data-bs-target="#addNewData">
                        Add Role
                    </button>
                    <a href="{{ route('permissions.index') }}" class="btn btn-secondary btn-set-task w-sm-100 ms-2">
                        Permissions
                    </a>
                </div>
            </div>
        </div>
    </div> <!-- Row end  -->

    <div class="card mb-3">
        <div class="card-body">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th width="5%">SL</th>
                        <th>Role Name</th>
                        <th width="15%">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($roles as $key => $data)
                        <tr>
                            <td> {{ $key + 1 }} </td>
                            <td>
                                {{ $data->name }}
                            </td>
                            <td>
                                <div class="btn-group" role="group" aria-label="Basic outlined example">
                                    <a class="btn btn-outline-secondary" href="{{ route('roles.show', $data->id) }}">
                                        <i class="mdi mdi-hexagon-outline text-success"></i>
                                    </a>
                                    <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal"
                                        data-bs-target="#editData-{{ $data->id }}">
                                        <i class="mdi mdi-pencil-box-outline text-warning"></i>
                                    </button>
                                    <a href="{{ route('roles.destroy', $data->id) }}" class="btn btn-outline-secondary"
                                        onclick="return confirm('are you sure ?')">
                                        <i class="mdi mdi-delete-variant text-danger"></i>
                                    </a>
                                </div>
                                <!-- Edit Data-->
                                <div class="modal fade" id="editData-{{ $data->id }}" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-md modal-dialog-scrollable">
                                        {{ html()->form('PUT', route('roles.update', $data->id))->class('w-100')->open() }}

                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title fw-bold" id="expaddLabel">Edit Role</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="name" class="form-label">Role Name <span
                                                            class="text-danger">*</span>:</label>
                                                    {{ html()->text('name', $data->name)->class('form-control')->placeholder('Role Name') }}
                                                    @if ($errors->has('name'))
                                                        <p class="help-block">{{ $errors->first('name') }}</p>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-warning"
                                                    data-bs-dismiss="modal">Cancel</button>
                                                {{ html()->submit('Submit')->class('btn btn-primary') }}
                                            </div>
                                        </div>

                                        {{ html()->form()->close() }}

                                    </div>
                                </div>

                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="3" class="text-center"> No data found! </td>
                        </tr>
                    @endforelse

                </tbody>
            </table>
        </div>
    </div><!-- Row End -->

    <!-- Add Data-->
    <div class="modal fade" id="addNewData" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md modal-dialog-scrollable">
            {{ html()->form('POST', route('roles.store'))->class('w-100')->open() }}
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="expaddLabel">Add Role</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="name" class="form-label">Role Name <span class="text-danger">*</span>:</label>
                        {{ html()->text('name')->class('form-control')->placeholder('Role Name') }}
                        @if ($errors->has('name'))
                            <p class="help-block">{{ $errors->first('name') }}</p>
                        @endif
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                    {{ html()->submit('Submit')->class('btn btn-primary') }}
                </div>
            </div>
            {{ html()->form()->close() }}


        </div>
    </div>
@endsection
