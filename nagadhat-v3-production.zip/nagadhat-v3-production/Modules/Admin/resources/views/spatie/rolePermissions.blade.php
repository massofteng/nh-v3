@extends('admin::layouts.app')
@section('page-content')
    <div class="row align-items-center">
        <div class="border-0 mb-4">
            <div
                class="card-header py-3 no-bg bg-transparent d-flex align-items-center px-0 justify-content-between border-bottom flex-wrap">
                <h3 class="fw-bold mb-0">Permissions of <b class="text-primary">{{ $role->name }}</b></h3>
                <div class="col-auto d-flex w-sm-100">
                    <a href="{{ route('roles.index') }}" class="btn btn-primary btn-set-task w-sm-100 ms-2">
                        Roles
                    </a>
                </div>
            </div>
        </div>
    </div> <!-- Row end  -->
    <div class="row clearfix g-3">
        <div class="col-sm-12">
            <div class="card mb-3">
                <div class="card-body">
                    <form action="{{ route('role-permission', $role->id) }}" method="post">
                        @csrf
                        <table class="table">
                            <tbody>
                                @foreach ($permissions->chunk(4) as $permission)
                                    <tr>
                                        @foreach ($permission as $data)
                                            <td>
                                                <?php
                                                $per_found = null;
                                                
                                                if (isset($role)) {
                                                    $per_found = $role->hasPermissionTo($data->name) ?? null;
                                                }
                                                
                                                if (isset($user)) {
                                                    $per_found = $user->hasDirectPermission($data->name);
                                                }
                                                ?>
                                                <div class="form-check form-switch">
                                                    <label class="form-check-label ms-2 {{ str_contains($data->name, 'delete') ? 'text-danger' : '' }}">
                                                        <input type="checkbox" name="permissions[]" value="{{ $data->name }}" class="form-check-input me-2" {{ $per_found ? 'checked' : '' }}>
                                                        {{ $data->name }}
                                                    </label>
                                                </div>
                                            </td>
                                        @endforeach
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
