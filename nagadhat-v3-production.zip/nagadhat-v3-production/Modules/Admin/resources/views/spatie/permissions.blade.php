@extends('admin::layouts.app')
@section('page-content')
    <div class="row align-items-center">
        <div class="border-0 mb-4">
            <div
                class="card-header py-3 no-bg bg-transparent d-flex align-items-center px-0 justify-content-between border-bottom flex-wrap">
                <h3 class="fw-bold mb-0">Permissions</h3>
                <div class="col-auto d-flex w-sm-100">
                    <button type="button" class="btn btn-dark btn-set-task w-sm-100" data-bs-toggle="modal"
                        data-bs-target="#addNewData">
                        Add Permission
                    </button>
                    <a href="{{ route('roles.index') }}" class="btn btn-secondary btn-set-task w-sm-100 ms-2">
                        Roles
                    </a>
                </div>
            </div>
        </div>
    </div> <!-- Row end  -->
    <div class="row clearfix g-3">
        <div class="col-sm-12">
            <div class="card mb-3">
                <div class="card-body">
                    <table class="table table-hover align-middle mb-0 w-100">
                        <thead>
                            <tr>
                                <th width="5%">SL</th>
                                <th>Permission Name</th>
                                <th width="15%">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($permissions as $key => $data)
                                <tr>
                                    <td>{{ $key + 1 }}</td>
                                    <td>
                                        {{ $data->name }}
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Basic outlined example">
                                            <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal"
                                                data-bs-target="#editData-{{ $data->id }}">
                                                <i class="mdi mdi-pencil-box-outline text-warning"></i>
                                            </button>
                                            <a href="{{ route('permissions.destroy', $data->id) }}"
                                                class="btn btn-outline-secondary"
                                                onclick="return confirm('are you sure ?')">
                                                <i class="mdi mdi-delete-variant text-danger"></i>
                                            </a>
                                        </div>
                                        <!-- Edit Data-->
                                        <div class="modal fade" id="editData-{{ $data->id }}" tabindex="-1"
                                            aria-hidden="true">
                                            <div
                                                class="modal-dialog modal-dialog-centered modal-md modal-dialog-scrollable">
                                                {{ html()->form('PUT', route('permissions.update', $data->id))->class('w-100')->open() }}
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title fw-bold" id="expaddLabel">Edit Permission
                                                        </h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <label for="name" class="form-label">Permission Name <span
                                                                    class="text-danger">*</span>:</label>
                                                            {{ html()->text('name', $data->name)->class('form-control')->placeholder('Permission Name') }}
                                                            @if ($errors->has('name'))
                                                                <p class="help-block">{{ $errors->first('name') }}</p>
                                                            @endif
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-warning"
                                                            data-bs-dismiss="modal">Cancel</button>
                                                        {{ html()->submit('Submit')->class('btn btn-primary') }}
                                                    </div>
                                                </div>
                                                {{ html()->form()->close() }}

                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4" class="text-center"> No data found! </td>
                                </tr>
                            @endforelse

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div><!-- Row End -->

    <!-- Add Data-->
    <div class="modal fade" id="addNewData" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md modal-dialog-scrollable">
            {{ html()->form('POST', route('permissions.store'))->class('w-100')->open() }}
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="expaddLabel">Add Permission</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="col-12 mb-3">
                        <label for="name" class="form-label">Permission <span class="text-danger">*</span>:</label>
                        {{ html()->text('name')->class('form-control')->placeholder('Permission Name') }}
                        @if ($errors->has('name'))
                            <p class="help-block">{{ $errors->first('name') }}</p>
                        @endif
                    </div>
                    <div class="col-12 mb-3">
                        {{ html()->select('type', ['1' => 'Normal', '2' => 'Resource'], '1')->class('form-select') }}
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                    {{ html()->submit('Submit')->class('btn btn-primary') }}
                </div>
            </div>
            {{ html()->form()->close() }}

        </div>
    </div>
@endsection
