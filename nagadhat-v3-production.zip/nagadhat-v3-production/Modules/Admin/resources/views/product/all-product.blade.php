@extends('admin::layouts.app')
@push('css')
    <link href="{{ asset('back-end/layouts/assets/css/product/all-product.css') }}" rel="stylesheet">
@endpush
@section('page-content')
    <div class="card">
        <div class="card-body">
            <div class="row all-product-title">
                <div class="col-md-12">
                    <div class="product-title d-flex align-items-center ">
                        <h5 class=" text-capitalize">products </h5>
                        <a href="#" class="btn btn-success text-capitalize">Add New</a>
                    </div>
                </div>
            </div>
            <div class="row product-search-area">
                <div class="col-md-12">
                    <div class="product-search d-flex align-items-center justify-content-between">
                        <div class="product-search-inner">
                            <div class="product-all-btn d-flex align-items-center">
                                <a href="#" class="active">All <span>(2041)</span></a>
                                <a href="#">Published <span>(201)</span></a>
                                <a href="#">Drafts <span>(110)</span></a>
                            </div>
                        </div>
                        <div class="product-search-inner">
                            <form class=" w-100">
                                <div class="d-flex align-items-center product-search-field">
                                    <input type="email" class="form-control" name="seach"
                                        placeholder="Product Search...">
                                    <button type="submit" class="search_btn text-capitalize"> Search Products</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row product-filter-area">
                <div class="col-md-12">
                    <div class="product-filter d-flex align-items-center justify-content-between">
                        <div class="product-filter-col d-flex align-items-center">
                            <div class="product-filter-section">
                                <form action="#">
                                    <div class="product-filter-section-inner d-flex align-items-center">
                                        <select class="form-control bulk-product-select" id="bulk-product-select"
                                            data-toggle="select2" data-width="100%">
                                            <option>Bulk Actions</option>
                                            <option value="HI">Hawaii</option>
                                            <option value="CA">California</option>
                                            <option value="NV">Nevada</option>
                                            <option value="OR">Oregon</option>
                                            <option value="WA">Washington</option>
                                        </select>
                                        <button class="product-filter-apply-btn">
                                            Apply
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <div class="product-filter-section">
                                <select class="form-control" id="category-select" data-toggle="select2" data-width="100%">
                                    <option>Filter By Category</option>
                                    <option value="AK">Bulk Actions</option>
                                    <option value="HI">Filter By Product Type</option>
                                    <option value="CA">California</option>
                                    <option value="NV">Nevada</option>
                                    <option value="OR">Oregon</option>
                                    <option value="WA">Washington</option>
                                </select>
                            </div>
                            <div class="product-filter-section">
                                <select class="form-control" id="product-type-select" data-toggle="select2" data-width="100%">
                                    <option>Filter By Product Type</option>
                                    <option value="AK">Bulk Actions</option>
                                    <option value="HI">Filter By Product Type</option>
                                    <option value="CA">California</option>
                                    <option value="NV">Nevada</option>
                                    <option value="OR">Oregon</option>
                                    <option value="WA">Washington</option>
                                </select>
                            </div>
                            <div class="product-filter-section">
                                <form action="#">
                                    <div class="product-filter-section-inner d-flex align-items-center">
                                        <select class="form-control stock-product-select" id="stock-product-select"
                                            data-toggle="select2" data-width="100%">
                                            <option>Filter By Stock Status</option>
                                            <option value="HI">Hawaii</option>
                                            <option value="CA">California</option>
                                            <option value="NV">Nevada</option>
                                            <option value="OR">Oregon</option>
                                            <option value="WA">Washington</option>
                                        </select>
                                        <button class="product-filter-apply-btn">
                                            Filter
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="product-filter-col">
                            <nav class=" d-flex justify-content-end ">
                                <ul class="pagination justify-content-center mb-0">
                                    <li class="page-item">
                                        <a class="page-link" href="#"><span >&laquo;</span>Previous</a>
                                    </li>
                                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item active"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item disabled"><a class="page-link" href="#">...</a></li>
                                    <li class="page-item"><a class="page-link" href="#">70</a></li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">Next <span>&raquo;</span></a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('scripts')

    <script src="{{ asset('back-end/layouts/assets/js/custom_all_product_page.js') }}"></script>
@endpush
