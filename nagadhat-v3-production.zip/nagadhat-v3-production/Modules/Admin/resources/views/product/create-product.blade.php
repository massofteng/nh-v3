@extends('admin::layouts.app')
@push('css')
    <link href="{{ asset('back-end/layouts/assets/libs/multiselect/css/multi-select.css') }}" rel="stylesheet"
        type="text/css" />
    <link href="{{ asset('back-end/layouts/assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css') }}"
        rel="stylesheet" type="text/css" />
    <link href="{{ asset('back-end/layouts/assets/libs/quill/quill.core.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('back-end/layouts/assets/libs/quill/quill.bubble.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('back-end/layouts/assets/libs/quill/quill.snow.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('back-end/layouts/assets/css/product/create-product.css') }}" rel="stylesheet">
@endpush
@section('page-content')
    <section>
        <form method="post" action="#">

            <div class="row create-product-section">
                <div class="col-xl-9">
                    <div class="card">
                        <div class="card-body">
                            <h1>Add New Product</h1>
                            <div class=" mb-2 form_item">
                                <label class=" col-form-label" for="productname">Product Name <span>*</span></label>
                                <input type="text" class="form-control" id="productname" name="productname"
                                    placeholder="e.g: Realme 5i Smartphone" autocomplete="">
                            </div>
                            <div class=" mb-2 form_item">
                                <label class="col-form-label" for="Keywords"> Keywords <span>*</span></label>
                                <input type="text" id="Keywords" name="Keywords" class="form-control"
                                    placeholder="Enter keyword....">
                            </div>
                            <div class=" mb-2 form_item">
                                <label class="col-form-label"> Short Description (Max: 250 words)</label>
                                <div>
                                    <div id="snow-editor-description" style="min-height: 150px;"
                                        class="form-control snow-editor-text" name="short_description">
                                    </div>
                                </div>
                            </div>
                            <div class=" mb-2 form_item">
                                <label class="col-form-label" for="short_description"> Full Description (Max: 1500 words)
                                    <span>*</span></label>
                                <div id="snow-editor" style="min-height: 200px;" class="form-control snow-editor-text"
                                    name="full_description">
                                </div>
                            </div>

                            <div class="mb-2 form_item">
                                <div class="row">
                                    <div class="col-6 form_item_category">
                                        <label class="col-form-label">Categories <span>*</span></label>
                                        <select class="form-control select2-multiple" data-toggle="select2"
                                            data-width="100%" multiple="multiple" data-placeholder="Select at least one...">
                                            <optgroup label="Alaskan/Hawaiian Time Zone">
                                                <option value="AK">Alaska</option>
                                                <option value="HI">Hawaii</option>
                                            </optgroup>
                                            <optgroup label="Pacific Time Zone">
                                                <option value="CA">California</option>
                                                <option value="NV">Nevada</option>
                                                <option value="OR">Oregon</option>
                                                <option value="WA">Washington</option>
                                            </optgroup>
                                        </select>
                                    </div>
                                    <div class="col-6 custom-dropdown-menu">
                                        <label class="col-form-label">Brand<span>*</span></label>
                                        <select class="form-control custom-select-formnh" data-toggle="select2"
                                            data-width="100%" name="brand">
                                            <option>Select</option>
                                            <optgroup label="Alaskan/Hawaiian Time Zone">
                                                <option value="AK">Alaska</option>
                                                <option value="HI">Hawaii</option>
                                            </optgroup>
                                        </select>
                                    </div>

                                </div>
                            </div>

                            <div class="mb-2 form_item">
                                <div class="row">
                                    <div class="col-6">
                                        <label class="col-form-label"> Purchases Rate<span>*</span></label>
                                        <input type="number" name="purchases_price" class="form-control">
                                    </div>
                                    <div class="col-6">
                                        <label class="col-form-label">
                                            MRP Rate
                                            <span>*</span>
                                        </label>
                                        <input type="number" name="mrp_price" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="mb-2 form_item custom-dropdown-menu">
                                <label for="select-type" class="form-label">Product Type</label>
                                <select class="form-control custom-select-formnh form_item_product_type"
                                    onchange="ProductVariantType()" id="product_type" name="product_type"
                                    data-toggle="select2" data-width="100%" name="brand">
                                    <option value="single" data-display="Select">Single</option>
                                    <option value="variants">Variants</option>
                                </select>
                            </div>
                            <div class="mb-3 form_item product_variation">

                                <div class="card">
                                    <div class="card-body">
                                        <div class="single_product_variation" id="single_product_variation">
                                            <div class="product_variation_title">
                                                <h4>Single Product</h4>
                                            </div>
                                            <div class="row">
                                                <div class="col-4">
                                                    <label class="col-form-label">Model <span>*</span> </label>
                                                    <input type="text" name="single_model" class="form-control">
                                                </div>
                                                <div class="col-4">
                                                    <label class="col-form-label">Barcode <span>*</span></label>
                                                    <input type="text" name="single_barcode" class="form-control">
                                                </div>
                                                <div class="col-4">
                                                    <label class="col-form-label">Sku (auto generated )</label>
                                                    <input type="text" name="single_sku" class="form-control">
                                                </div>
                                            </div>
                                        </div>

                                        <div id="product_variation" class="variation_product_box">
                                            <div class="product_variation_title">
                                                <h4>Product Variations</h4>
                                            </div>
                                            <div class="product_variant_generate_holder d-flex align-items-center ">
                                                <select class="form-control select2-multiple " onchange="generateProductVariantType()" id="generate_product_variant_type" data-toggle="select2"
                                                data-width="100%" multiple="multiple" name="generate_product_variant">
                                                    <option value="color">Color</option>
                                                    <option value="size">Size</option>
                                                    <option value="weight">Weight</option>
                                            </select>
                                            <div class="variant_generate_btn_area flex-shrink-0 ">
                                                <button type="button" class="btn btn-success text-capitalize" onclick="variantionMainFunction()">Generate Variant</button>
                                            </div>
                                            </div>
                                            <div class="after_variant_select_box pt-3">
                                                <div class="row mb-2">
                                                    <div class="col-4" >
                                                        <label class="col-form-label">Model</label>
                                                        <input type="text" name="variation_model" class="form-control">
                                                    </div>
                                                    <div class="col-4" >
                                                        <label class="col-form-label">Barcode</label>
                                                        <input type="text" name="variation_barcode" class="form-control">
                                                    </div>
                                                    <div class="col-4" >
                                                        <label class="col-form-label">Sku</label>
                                                        <input type="text" name="variation_sku" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="row mb-2">
                                                    <div class="col-4 product_variation_item product_variation_item_size">
                                                        <label class="form-label">Size</label>
                                                        <select class="form-control custom-select-formnh" name="product_size"
                                                            data-toggle="select2" data-width="100%" name="brand">
                                                            <option>Select</option>
                                                            <optgroup label="All Size">
                                                                <option value="39">39</option>
                                                                <option value="42">42</option>
                                                                <option value="m">m</option>
                                                                <option value="l">l</option>
                                                                <option value="xl">xl</option>
                                                            </optgroup>
                                                        </select>
                                                    </div>
                                                    <div class="col-4 product_variation_item product_variation_item_color">
                                                        <label class="form-label"> Color</label>
                                                        <select class="form-control custom-select-formnh" name="product_color"
                                                            data-toggle="select2" data-width="100%" name="brand">
                                                            <option>Select</option>
                                                            <optgroup label="All Color">
                                                                <option value="red">red</option>
                                                                <option value="blue">blue</option>
                                                                <option value="black">black</option>
                                                                <option value="yelow">yelow</option>
                                                            </optgroup>
                                                        </select>
                                                    </div>
                                                    <div class="col-4 product_variation_item product_variation_item_weight">
                                                        <label class="form-label"> Weight</label>
                                                        <select class="form-control custom-select-formnh"
                                                            name="product_weight" data-toggle="select2" data-width="100%"
                                                            name="brand">
                                                            <option>Select</option>
                                                            <optgroup label="All Weight">
                                                                <option value="1kg">1kg</option>
                                                                <option value="2kg">2kg</option>
                                                                <option value="500g">500g</option>
                                                                <option value="5pic">5pic</option>
                                                            </optgroup>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row mb-2">
                                                    <div class="col-4 product_variation_item">
                                                        <label class="col-form-label">
                                                            Regular Price
                                                        </label>
                                                        <input type="number" name="variation_price" class="form-control"
                                                            value="750">
                                                    </div>
                                                    <div class="col-4 product_variation_item">
                                                        <label class="col-form-label">
                                                            Discount Price
                                                        </label>
                                                        <input type="number" name="variation_discount" class="form-control"
                                                            value='1112'>
                                                    </div>
                                                    <div class="col-4 product_variation_item">
                                                        <label class="form-label"> Discount type</label>
                                                        <select class="form-control custom-select-formnh" name="discount_type"
                                                            data-toggle="select2" data-width="100%" name="brand">
                                                            <option value="percentage" selected>Percentage(%)</option>
                                                            <option value="flat">Flat</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="card-box">
                                                        <div class="card-body-box px-0 product-variation-multiple-image-area">
                                                            <h4 class="header-title">Product Variations Gallery</h4>
                                                            <div method="post" action="#" class="dropzone"
                                                                id="variant-Dropzone" data-plugin="dropzone"
                                                                data-previews-container="#variants-file-previews"
                                                                data-upload-preview-template="#variantUploadPreviewTemplate"
                                                                data-height="100">
                                                                <div class="fallback">
                                                                    <input name="file" type="file" multiple />
                                                                </div>
                                                                <div class="dz-message needsclick">
                                                                    <i class="h1 text-muted dripicons-cloud-upload"></i>
                                                                    <p> Click to Upload Multiple Image.</p>
                                                                </div>
                                                            </div>
                                                            <!-- Preview -->
                                                            <div class="dropzone-previews mt-3" id="variants-file-previews">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="d-none" id="variantUploadPreviewTemplate">
                                                        <div class="card mt-1 mb-0 shadow-none border">
                                                            <div class="p-2">
                                                                <div class="row align-items-center">
                                                                    <div class="col-auto">
                                                                        <img data-dz-thumbnail src="#"
                                                                            class="avatar-sm rounded bg-light" alt="">
                                                                    </div>
                                                                    <div class="col ps-0">
                                                                        <a href="javascript:void(0);"
                                                                            class="text-muted fw-bold" data-dz-name></a>
                                                                        <p class="mb-0" data-dz-size></p>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <a href="#"
                                                                            class="btn btn-link btn-lg text-muted"
                                                                            data-dz-remove>
                                                                            <i class="dripicons-cross"></i>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                {{-- Product Variations Gallery --}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-2 form_item product_photo_area">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="card">
                                            <div class="card-body px-0">
                                                <h4 class="header-title">Thumbnail</h4>
                                                <input type="file" data-plugins="dropify" name="product_thumbnail"
                                                    data-height="150" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="card">
                                            <div class="card-body px-0 product-multiple-image-area">
                                                <h4 class="header-title">Product Gallery</h4>
                                                <div method="post" action="#" class="dropzone"
                                                    id="myAwesomeDropzone" data-plugin="dropzone"
                                                    data-previews-container="#file-previews"
                                                    data-upload-preview-template="#uploadPreviewTemplate"
                                                    data-height="200">
                                                    <div class="fallback">
                                                        <input name="file" type="file" multiple />
                                                    </div>
                                                    <div class="dz-message needsclick">
                                                        <i class="h1 text-muted dripicons-cloud-upload"></i>
                                                        <p> Click to Upload Multiple Image.</p>
                                                    </div>
                                                </div>
                                                <!-- Preview -->
                                                <div class="dropzone-previews mt-3" id="file-previews"></div>
                                            </div>
                                        </div>
                                        <div class="d-none" id="uploadPreviewTemplate">
                                            <div class="card mt-1 mb-0 shadow-none border">
                                                <div class="p-2">
                                                    <div class="row align-items-center">
                                                        <div class="col-auto">
                                                            <img data-dz-thumbnail src="#"
                                                                class="avatar-sm rounded bg-light" alt="">
                                                        </div>
                                                        <div class="col ps-0">
                                                            <a href="javascript:void(0);" class="text-muted fw-bold"
                                                                data-dz-name></a>
                                                            <p class="mb-0" data-dz-size></p>
                                                        </div>
                                                        <div class="col-auto">
                                                            <a href="#" class="btn btn-link btn-lg text-muted"
                                                                data-dz-remove>
                                                                <i class="dripicons-cross"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row py-4">
                                    <div class="col">
                                        <div class="product-add-btn text-center">
                                            <button type="submit" class="btn btn-success">Add Product</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3">
                    <div class="right-side-holder">
                        <div class="card right-side-box mb-3">
                            <div class="card-body">
                                <h4 class="header-title mb-3"> Shipping Configuration</h4>
                                <div class="d-flex align-items-baseline pb-2">
                                    <span>Free Shipping</span>
                                    <div class="switchery-demo">
                                        <input type="checkbox" checked data-plugin="switchery" name="free_shipping"
                                            data-color="#1bb99a" data-size="small" />
                                    </div>
                                </div>
                                <div class="pb-2">
                                    <label class=" form-label">Or Flat Rate</label>
                                    <input id="flat_rate" type="number" value="60" name="flatDeliveryCrg"
                                        class=" form-control">
                                </div>
                                <div class="d-flex align-items-baseline ">
                                    <span>Cash on Delivery</span>
                                    <div class="switchery-demo">
                                        <input type="checkbox" checked data-plugin="switchery"name="cash_on_delivery"
                                            data-color="#1bb99a" data-size="small" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card right-side-box mb-3">
                            <div class="card-body">
                                <h4 class="header-title mb-3"> Max Quantity</h4>
                                <div class="pb-0">
                                    <label class=" form-label">Max Purchase Quantity</label>
                                    <input id="flat_rate" type="number" value="1" name="max_quantity"
                                        class=" form-control">
                                    <span class=" text-blue">* if this value is null then no purchase limit for this
                                        product.</span>
                                </div>
                            </div>
                        </div>
                        <div class="card right-side-box mb-3">
                            <div class="card-body">
                                <h4 class="header-title mb-3"> Product Video</h4>
                                <p>Video Platform</p>
                                <select class="custom-select mt-1 form-control" name="videoPlatForm">
                                    <option value="notSelect" selected="">Select Video Platform</option>
                                    <option value="Youtube">Youtube</option>
                                </select>
                                <div class="form-group mt-1">
                                    <span>Video Link</span>
                                    <input type="text" class="form-control mt-1" id="product-video"
                                        placeholder="Enter video link" name="videoLink">
                                    <small class="form-text text-muted">Please don't use any short link
                                        here</small>
                                </div>
                            </div>
                        </div>
                        <div class="card right-side-box mb-3" id="p-offer-discount-box">
                            <div class="card-body">
                                <h4 class="header-title mb-3"> Offer and Discount</h4>
                                <p>Discount Type</p>
                                <select class="custom-select mt-1 form-control" name="discountType">
                                    <option selected="" value="notSelect">Select a option</option>
                                    <option value="percentage">Percentage</option>
                                    <option value="flat">Flat</option>
                                </select>
                                <div class="form-group mt-1">
                                    <span>Discount Number</span>
                                    <input type="number" step="0.01" class="form-control mt-1" id="discount"
                                        placeholder="Discount number" name="discountAmount" value="0">
                                    <small class="form-text text-muted">Percentage will automatically
                                        convert in number(TK).</small>
                                </div>
                            </div>
                        </div>
                        <div class="card right-side-box mb-3 border border-warning">
                            <div class="card-body">
                                <h4 class="header-title mb-3">Earning Limit Multiplier</h4>
                                <div class="form-group mt-1">
                                    <input type="number" step="0.01" class="form-control mt-1"
                                        id="earning_limit_multiplier" name="earning_limit_multiplier">
                                    <small class="form-text text-warning">
                                        Enter the amount to multiply with the price to set user
                                        <strong>earning limit</strong>
                                    </small>
                                </div>
                            </div>
                        </div>
                        <div class="card right-side-box mb-3 ">
                            <div class="card-body">
                                <h4 class="header-title mb-3">Affiliate Commission</h4>
                                <div class="affiliate_commission_area d-flex align-items-center justify-content-between ">
                                    <div class="form-check form-check-success">
                                        <input class="form-check-input" type="radio" value="auto affiliate"
                                            name="affiliate_commission" id="auto_affiliate" checked>
                                        <label class="form-check-label text-capitalize" for="auto_affiliate">auto
                                            affiliate</label>
                                    </div>
                                    <div class="form-check form-check-success">
                                        <input onchange="affi" class="form-check-input" type="radio"
                                            value="menual affiliate" name="affiliate_commission" id="menual_affiliate">
                                        <label class="form-check-label text-capitalize" for="menual_affiliate">menually
                                            affiliate</label>
                                    </div>
                                </div>
                                <div class="affiliate-commission-manually">
                                    <div class="form-group ">
                                        <span>L5 Commission(%)</span>
                                        <input type="number" step="0.01" class="form-control mt-1"
                                            id="L1_commission" name="L1_commission">
                                    </div>
                                    <div class="form-group mt-1 ">
                                        <span>L4 Commission(%)</span>
                                        <input type="number" step="0.01" class="form-control mt-1"
                                            id="L2_commission" name="L2_commission">
                                    </div>
                                    <div class="form-group mt-1">
                                        <span>L3 Commission(%)</span>
                                        <input type="number" step="0.01" class="form-control mt-1"
                                            id="L3_commission" name="L3_commission">
                                    </div>
                                    <div class="form-group mt-1">
                                        <span>L2 Commission(%)</span>
                                        <input type="number" step="0.01" class="form-control mt-1"
                                            id="L4_commission" name="L4_commission">
                                    </div>
                                    <div class="form-group mt-1">
                                        <span>L1 Commission(%)</span>
                                        <input type="number" step="0.01" class="form-control mt-1"
                                            id="L5_commission" name="L5_commission">
                                    </div>
                                    <div class="form-group mt-1">
                                        <span>Total product Commission</span>
                                        <small class="form-text text-muted">Percentage will
                                            automatically convert in number(TK).</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card right-side-box mb-3 ">
                            <div class="card-body">
                                <h4 class="header-title mb-3 text-capitalize">search engine content</h4>
                                <div class="seo_info_area">
                                    <div class=" mb-2 form_item">
                                        <label class=" col-form-label text-capitalize" for="seo_title">Product Title </label>
                                        <input type="text" class="form-control" id="seo_title" name="seo_title"
                                            placeholder="Enter Product Title" autocomplete="">
                                    </div>
                                    <div class=" mb-2 form_item">
                                        <label class=" col-form-label text-capitalize" for="seo_description">Description </label>
                                        <textarea class="form-control" placeholder="Enter Product Description..." name="seo_description" id="seo_description" style="height: 100px"></textarea>
                                    </div>
                                    <div class=" form_item">
                                        <div class="card">
                                            <div class="card-body px-0 py-1">
                                                <h4 class="header-title">Thumbnail</h4>
                                                <input type="file" data-plugins="dropify" name="product_thumbnail"
                                                    data-height="150" />
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </section>
@endsection

@push('scripts')
    <script src="{{ asset('back-end/layouts/assets/libs/multiselect/js/jquery.multi-select.js') }}"></script>
    <script src="{{ asset('back-end/layouts/assets/libs/jquery-mockjax/jquery.mockjax.min.js') }}"></script>
    <script src="{{ asset('back-end/layouts/assets/libs/devbridge-autocomplete/jquery.autocomplete.min.js') }}"></script>
    <script src="{{ asset('back-end/layouts/assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js') }}">
    </script>
    <script src="{{ asset('back-end/layouts/assets/libs/quill/quill.min.js') }}"></script>
    <script src="{{ asset('back-end/layouts/assets/js/pages/form-quilljs.init.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap-wizard/1.2/jquery.bootstrap.wizard.js"></script>
    <script src="{{ asset('back-end/layouts/assets/js/custom_product_variant.js') }}"></script>
@endpush
