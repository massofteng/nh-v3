<!-- ========== Left Sidebar Start ========== -->
<div class="left-side-menu">
    <div class="h-100" data-simplebar>
        <!-- User box -->
        <div class="user-box text-center">
            <img src="{{ asset('back-end/layouts/assets/images/users/user-1.jpg') }}" alt="user-img" title="Mat Helme"
                class="rounded-circle img-thumbnail avatar-md">
            <p class="text-muted left-user-info">Admin Head</p>
            <ul class="list-inline">
                <li class="list-inline-item">
                    <a href="#">
                        <i class="mdi mdi-power"></i>
                        Logout
                    </a>
                </li>
            </ul>
        </div>
        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <ul id="side-menu">
                <li>
                    <a href="{{ route('admin_dashboard') }}">
                        <i class="mdi mdi-view-dashboard-outline"></i>
                        <span class="badge bg-success rounded-pill float-end"></span>
                        <span> Dashboard </span>
                    </a>
                </li>
                <li class="menu-title mt-2">BRAND</li>
                <li>
                    <a href="#brand" data-bs-toggle="collapse">
                        <i class="fas fa-indent"></i>
                        <span>Brands</span>
                        <span class="menu-arrow"></span>
                    </a>
                    <div class="collapse" id="brand">
                        <ul class="nav-second-level">
                            <li>
                                <a href="#">
                                    <i class="fas fa-arrow-circle-right"></i>
                                    Manage Brands
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('add_brand_page') }}">
                                    <i class="fas fa-arrow-circle-right"></i>
                                    Add Brands
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class="menu-title mt-2">CATEGORIES</li>
                <li>
                    <a href="#category" data-bs-toggle="collapse">
                        <i class="fas fa-dolly"></i>
                        <span>Categories</span>
                        <span class="menu-arrow"></span>
                    </a>
                    <div class="collapse" id="category">
                        <ul class="nav-second-level">
                            <li>
                                <a href="#">
                                    <i class="fas fa-arrow-circle-right"></i>
                                    Manage Categories
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('add_category') }}">
                                    <i class="fas fa-arrow-circle-right"></i>
                                    Add Categories
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class="menu-title mt-2">ROLES & PERMISSION</li>
                <li>
                    <a href="#rolesPermission" data-bs-toggle="collapse">
                        <i class="fas fa-user-lock"></i>
                        <span>Roles & Permissions</span>
                        <span class="menu-arrow"></span>
                    </a>
                    <div class="collapse" id="rolesPermission">
                        <ul class="nav-second-level">
                            <li>
                                <a href="{{ route('roles.index') }}">
                                    <i class="fas fa-arrow-circle-right"></i>
                                    Roles
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('permissions.index') }}">
                                    <i class="fas fa-arrow-circle-right"></i>
                                    Permissions
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li>
                    <a href="#producttask" data-bs-toggle="collapse">
                        <i class="mdi mdi-clipboard-outline"></i>
                        <span> Products </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <div class="collapse" id="producttask">
                        <ul class="nav-second-level">
                            <li>
                                <a href="{{ route('products') }}">
                                    <i class=" fas fa-arrow-circle-right"></i>
                                     All Product
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('create_product') }}">
                                    <i class=" fas fa-arrow-circle-right"></i>
                                    Add Product
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
        <!-- End Sidebar -->
        <div class="clearfix"></div>
    </div>
    <!-- Sidebar -left -->
</div>
<!-- Left Sidebar End -->
