<!-- End Footer Content -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <script>
                    document.write(new Date().getFullYear())
                </script> &copy; Develop by <a href="#">Global Fast Coder</a>
            </div>
            <div class="col-md-6">
                <div class="text-md-end footer-links d-none d-sm-block">
                    <a href="https://globalfastcoder.com/" target="_blank">About Us</a>
                    <a href="https://globalfastcoder.com/" target="_blank">Help</a>
                    <a href="https://globalfastcoder.com/" target="_blank">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer Content -->
