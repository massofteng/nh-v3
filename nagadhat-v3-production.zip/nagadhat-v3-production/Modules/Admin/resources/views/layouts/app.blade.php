<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Nagadhat | Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="{{asset('back-end/media/images/fav-icon/favicon.png')}}">
    <!-- App css -->
    <link href="{{ asset('back-end/layouts/assets/css/style.css') }}" rel="stylesheet" type="text/css" id="app-style" />
    <link href="{{ asset('back-end/layouts/assets/css/add-category.css') }}" rel="stylesheet" type="text/css" id="app-style" />
    <!-- icons -->
    <link href="{{ asset('back-end/layouts/assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
    <!-- select2 -->
    <link href="{{asset('back-end/layouts/assets/libs/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css" />
    <!-- Dropify Plugins css -->
    <link href="{{asset('back-end/layouts/assets/libs/dropzone/min/dropzone.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('back-end/layouts/assets/libs/dropify/css/dropify.min.css')}}" rel="stylesheet" type="text/css" />
    <!-- switchcherry -->
    <link href="{{asset('back-end/layouts/assets/libs/mohithg-switchery/switchery.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('back-end/layouts/assets/libs/selectize/css/selectize.bootstrap3.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('back-end/layouts/assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css')}}" rel="stylesheet" type="text/css" />
    <!-- sweet alert css-->
    <link rel="stylesheet" href="{{ asset('back-end/sweetalert2/sweetalert2.min.css') }}">
    <!-- Connect Css -->
    @stack('css')
</head>
<!-- body start -->

<body class="loading" data-layout-color="light" data-layout-mode="default" data-layout-size="fluid"
    data-topbar-color="light" data-leftbar-position="fixed" data-leftbar-color="light" data-leftbar-size='default'
    data-sidebar-user='true'>
    <!-- Begin page -->
    <div id="wrapper">
        @include('admin::layouts.header')
        @include('admin::layouts.left-sidebar')
        @include('admin::layouts.footer')

        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->
        <div class="content-page">
            <div class="content">
                <!-- Start Content-->
                <div class="container-fluid">

                    @yield('page-content')

                </div>
            </div>
        </div>

        <!-- ============================================================== -->
        <!-- End Page Content here -->
        <!-- ============================================================== -->

        <!-- END wrapper -->
        <!-- Vendor -->
        <script src="{{ asset('back-end/layouts/assets/libs/jquery/jquery.min.js') }}"></script>
        <script src="{{ asset('back-end/layouts/assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
        <script src="{{ asset('back-end/layouts/assets/libs/simplebar/simplebar.min.js') }}"></script>
        <script src="{{ asset('back-end/layouts/assets/libs/node-waves/waves.min.js') }}"></script>
        <script src="{{ asset('back-end/layouts/assets/libs/waypoints/lib/jquery.waypoints.min.js') }}"></script>
        <script src="{{ asset('back-end/layouts/assets/libs/jquery.counterup/jquery.counterup.min.js') }}"></script>
        <script src="{{ asset('back-end/layouts/assets/libs/feather-icons/feather.min.js') }}"></script>
        <!-- knob plugin -->
        <script src="{{ asset('back-end/layouts/assets/libs/jquery-knob/jquery.knob.min.js') }}"></script>
        <!--Morris Chart-->
        <script src="{{ asset('back-end/layouts/assets/libs/morris.js06/morris.min.js') }}"></script>
        <script src="{{ asset('back-end/layouts/assets/libs/raphael/raphael.min.js') }}"></script>
        <!-- Dashboar init js-->
        <script src="{{ asset('back-end/layouts/assets/js/pages/dashboard.init.js') }}"></script>
        <!-- App js-->
        <script src="{{ asset('back-end/layouts/assets/js/app.min.js') }}"></script>
        <!-- Select2 -->
        <script src="{{asset('back-end/layouts/assets/libs/select2/js/select2.min.js')}}"></script>
        <!-- Dropify Plugins js -->
        <script src="{{asset('back-end/layouts/assets/libs/dropzone/min/dropzone.min.js')}}"></script>
        <script src="{{asset('back-end/layouts/assets/libs/dropify/js/dropify.min.js')}}"></script>
        <!--Dropify Init js-->
        <script src="{{asset('back-end/layouts/assets/js/pages/form-fileuploads.init.js')}}"></script>
        <!-- switchery -->
        <script src="{{asset('back-end/layouts/assets/libs/mohithg-switchery/switchery.min.js')}}"></script>
        <script src="{{asset('back-end/layouts/assets/libs/selectize/js/standalone/selectize.min.js')}}"></script>
        <script src="{{asset('back-end/layouts/assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')}}"></script>
        {{-- Init js --}}
        <script src="{{asset('back-end/layouts/assets/js/pages/form-advanced.init.js')}}"></script>
        {{-- include sweetalert --}}
        @include('sweetalert::alert')
        @stack('scripts')
</body>

</html>