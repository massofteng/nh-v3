@php
    $title = 'Add Brand';
@endphp
@extends('admin::layouts.app')
@section('page-content')
    <form action="{{ route('add_brand') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="row">
            <div class="col-9">
                <div class="card">
                    <div class="card-body">
                        <h2 class="text-center">{{ $title }}</h2>
                        <p class="sub-header text-center text-danger">
                            (Please add Logo and Banner for every brand)
                        </p>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Brand Name<span
                                            class="text-danger">*</span>:</label>
                                    <input type="text" name="title" id="simpleinput"
                                        class="form-control @error('title') border border-danger @enderror"
                                        placeholder="Brand Name">
                                    @error('title')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Description:</label>
                                    <textarea id="textarea" name="description" class="form-control" maxlength="300" rows="5"></textarea>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Logo<span
                                            class="text-danger">*</span>:</label>
                                    <input type="file" name="logo" data-plugins="dropify" data-height="200" />
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Banner:</label>
                                    <input type="file" name="banner" data-plugins="dropify" data-height="200" />
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <div class="" style="margin-right:10px;">
                                    <a href="#" class="btn btn-danger">
                                        Back
                                    </a>
                                </div>
                                <div class="">
                                    <button type="submit" class="btn btn-success">
                                        Add Brand
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-3">
                <div class="card">
                    <div class="card-body">
                        <h4 class="text-center">Others Configuration</h4>
                        <div class="row">
                            <div class="switchery-demo" style="margin-left: 10px;">
                                <span>Active Status</span>
                                <input id="statusCheckbox" type="checkbox" data-plugin="switchery" data-color="#47B755"
                                    data-size="small" />
                                <input type="hidden" name="status" id="hiddenStatus" value="0">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection
@push('scripts')
<script src="{{asset('back-end/layouts/assets/js/brand.js')}}"></script>
@endpush
