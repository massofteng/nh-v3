<?php

namespace Modules\Admin\App\Http\Controllers\spatie;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;


class RolesController extends Controller
{
    // function to for role index
    public function index()
    {
        // Retrieve all roles from the database
        $roles = Role::all();

        // Return the 'admin::spatie.roles' view with the roles data
        return view('admin::spatie.roles', compact('roles'));
    }

    // function to store a role
    public function store(Request $request)
    {
        // Validate the incoming request data
        $request->validate(['name' => 'required|unique:roles']);

        try {
            // Create a new role with the provided name
            Role::create($request->only('name'));

            // Redirect back with success message
            return redirect()->back()->with('success', 'Successfully added');
        } catch (\Exception $e) {
            // Redirect back with error message if an exception occurs
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    // function to show role
    public function show($id)
    {
        // Clear cached permissions
        app()[PermissionRegistrar::class]->forgetCachedPermissions();

        // Find the role with the given ID
        $role = Role::findOrFail($id);

        // Retrieve all permissions
        $permissions = Permission::all();

        // Return the 'admin::spatie.rolePermissions' view with the role and permissions data
        return view('admin::spatie.rolePermissions', compact('role', 'permissions'));
    }

    // function to update a role
    public function update(Request $request, $id)
    {
        // Validate the incoming request data
        $request->validate(['name' => "required|unique:roles,name,$id"]);

        try {
            // Find the role with the given ID
            $role = Role::findOrFail($id);

            // Update the role's name
            $role->update([
                'name' => $request->name
            ]);

            // Redirect back with success message
            return redirect()->back()->with('success', 'Role has been updated');
        } catch (\Exception $e) {
            // Redirect back with error message if an exception occurs
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    // function to delete a role
    public function destroy($id)
    {
        try {
            // Find the role with the given ID
            $data = Role::findOrFail($id);

            // Delete the role
            $data->delete();

            // Redirect back with success message
            return redirect()->back()->with('success', 'Role is deleted');
        } catch (\Exception $e) {
            // Redirect back with error message if an exception occurs
            return redirect()->back()->with('error',  $e->getMessage());
        }
    }
    
    // function to update permissions to a role
    public function rolePermissionUpdate(Request $request, $id)
    {
        try {
            // Clear cached permissions
            app()[PermissionRegistrar::class]->forgetCachedPermissions();

            // Find the role with the given ID
            if ($role = Role::findOrFail($id)) {
                // If the role is Administrator, grant all permissions
                if ($role->name === 'Administrator') {
                    $role->syncPermissions(Permission::all());
                    return redirect()->route('roles.index')->with('success', 'Set all permissions to Administrator role.');
                }

                // Otherwise, sync permissions with the ones provided in the request
                $permissions = $request->get('permissions', []);
                $role->syncPermissions($permissions);
                return redirect()->route('roles.index')->with('success', $role->name . ' permissions has been updated');
            }
        } catch (\Exception $e) {
            // Redirect back with error message if an exception occurs
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

}
