<?php

namespace Modules\Admin\App\Http\Controllers\spatie;

use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Spatie\Permission\Models\Permission;

class PermissionsController extends Controller
{
    // function to for permission index
    public function index()
    {
        // Fetch all permissions from the database
        $permissions = Permission::all();

        // Return the 'spatie.permissions' view with the permissions data
        return view('admin::spatie.permissions', compact('permissions'));
    }

    // function to store a permission
    public function store(Request $request)
    {
        // Validate the incoming request data
        $request->validate([
            'name' => 'required|unique:permissions', // Ensure name is required and unique in permissions table
            'type' => 'required' // Ensure type is required
        ]);

        try {
            // Convert name to slug format
            $name = Str::slug($request->name);

            if ($request->type == 1) {
                // Create a permission with the given name
                Permission::create([
                    'name' => $name
                ]);
                $message = 'Permission added'; // Set success message
            } else {
                // Resource Permission create
                Permission::create(['name' => 'view-' . $name]);
                Permission::create(['name' => 'add-' . $name]);
                Permission::create(['name' => 'edit-' . $name]);
                Permission::create(['name' => 'delete-' . $name]);
                $message = 'Resource permission added'; // Set success message
            }

            // Redirect back with success message
            return redirect()->back()->with('success', $message);
        } catch (\Exception $e) {
            // Redirect back with error message if an exception occurs
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    // function to update a permission
    public function update(Request $request, $id)
    {
        // Validate the incoming request data
        $request->validate(['name' => "required|unique:permissions,name,$id"]);

        try {
            // Convert name to slug format
            $name = Str::slug($request->name);

            // Find the permission with the given ID
            if ($data = Permission::findOrFail($id)) {
                // Update the name of the permission
                $data->update([
                    'name' => $name
                ]);
                return redirect()->back()->with('success', "Permission has been updated"); // Set success message
            }
        } catch (\Exception $e) {
            // Redirect back with error message if an exception occurs
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    // function to delete a permission
    public function destroy($id)
    {
        try {
            // Find the permission with the given ID
            $data = Permission::findOrFail($id);

            // Delete the permission
            $data->delete();

            // Redirect back with success message
            return redirect()->back()->with('success', 'Permission is deleted');
        } catch (\Exception $e) {
            // Redirect back with error message if an exception occurs
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
