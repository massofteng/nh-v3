<?php

namespace Modules\Admin\App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class AdminDashboardController extends Controller
{
    public function adminDashboard()
    {
        return view('admin::dashboard.admin-dashboard');
    }

    public function test()
    {
        return view('admin::dashboard.test');
    }
}
