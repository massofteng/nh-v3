<?php

namespace Modules\Admin\App\Http\Controllers\product;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class ProductController extends Controller
{

    public function allProduct(){
        return view('admin::product.all-product');
    }

    public function createProduct() {
        return view('admin::product.create-product');
    }
}
