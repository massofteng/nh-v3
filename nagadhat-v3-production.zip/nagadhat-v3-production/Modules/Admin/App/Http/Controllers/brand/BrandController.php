<?php

namespace Modules\Admin\App\Http\Controllers\brand;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Modules\Admin\App\Http\Requests\AddBrandRequest;
use Modules\Admin\App\Repositories\interfaces\BrandRepositoryInterface;

class BrandController extends Controller
{
    // Function to call brand repository
    public function __construct( private BrandRepositoryInterface $brandRepository)
    {
        $this->brandRepository = $brandRepository;
    }

    public function addBrandView()
    {
        return view('admin::brand.add-brand');
    }

    public function addBrand(AddBrandRequest $request)
    {
        try {
            $data = $request->validated();
            if (auth()->user()->user_type == 1) {
                $this->brandRepository->addBrand($data);
                toast('Brand created successfully.', 'success');
                return redirect()->back();
            } else {
                toast('You are not authorized.', 'error');
                return redirect()->back();
            }
        } catch (\Exception $e) {
            toast('An error occurred while adding the brand: ' . $e->getMessage(), 'error');
            return redirect()->back();
        }
    }
    
}
