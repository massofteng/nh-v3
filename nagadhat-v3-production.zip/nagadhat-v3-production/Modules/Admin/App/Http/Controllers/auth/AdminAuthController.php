<?php

namespace Modules\Admin\App\Http\Controllers\auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;

class AdminAuthController extends Controller
{
    // function to admin login
    public function adminLogin(Request $request)
    {
        // check method
        if ($request->isMethod('post')) {
            $request->validate([
                'email' => 'required',
                'password' => 'required',
            ]);
            // check credential 
            $credentials = $request->only('email', 'password');
            try {
                if (Auth::attempt($credentials, true)) {
                    $request->session()->regenerate();
                    if (Auth::user()->user_type == 1) {
                        Alert::success('Success', 'Login Successfully');
                        return redirect()->route('admin_dashboard');
                    } else {
                        return redirect()->back();
                    }
                } else {
                    return redirect()->back()->with('error', 'Invalid email or password.');
                }
            } catch (\Throwable $th) {
                //throw $th;
            }   
        }else {
            return view('admin::auth.admin-login');
        }
    }

    // funtion to admin logout
    public function adminLogout()
    {
        Auth::logout();
        return redirect()->route('admin_login');
    }

    public function adminRegister()
    {
        return view('admin::auth.admin-registration');
    }
}
