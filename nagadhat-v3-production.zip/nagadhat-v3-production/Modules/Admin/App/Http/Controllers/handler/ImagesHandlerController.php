<?php

namespace Modules\Admin\App\Http\Controllers\handler;

use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Controller;

class ImagesHandlerController extends Controller
{
    /**---Common function to upload image--**/

    function uploadImage($file, $path = null)
    {
        $filename_image = $file->getClientOriginalName();
        $file->move(public_path($path), $filename_image);
        return $path . $filename_image;
    }
}
