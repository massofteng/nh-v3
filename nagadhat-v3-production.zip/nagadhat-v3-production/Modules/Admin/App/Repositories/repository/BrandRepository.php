<?php

namespace Modules\Admin\App\Repositories\repository;

use App\Models\Brand;
use Modules\Admin\App\Repositories\interfaces\BrandRepositoryInterface;
use Modules\Admin\App\Http\Controllers\handler\ImagesHandlerController;

class BrandRepository implements BrandRepositoryInterface{
    // Function to add brand
    public function addBrand(array $data)
    {
        // get image funtion from ImageHandler controller
        $imageHandler = new ImagesHandlerController(); 
        $imageLogo = $imageHandler->uploadImage($data["logo"], "storage/media/brand/logo");
        $imageBanner = $imageHandler->uploadImage($data["banner"], "storage/media/brand/banner");
        Brand::saveBrand($data, $imageLogo, $imageBanner);
    }
}
