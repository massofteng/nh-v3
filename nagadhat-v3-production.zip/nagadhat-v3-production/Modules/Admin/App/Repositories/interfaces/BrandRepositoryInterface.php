<?php

namespace Modules\Admin\App\Repositories\interfaces;
interface BrandRepositoryInterface{
    public function addBrand(array $data);
}
