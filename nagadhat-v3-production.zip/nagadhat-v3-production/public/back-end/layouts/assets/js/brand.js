// function to brans check status
$(document).ready(function() {
    var checkbox = document.querySelector('#statusCheckbox');
    var hiddenStatus = document.querySelector('#hiddenStatus');
    checkbox.addEventListener('change', function(event) {
        if (checkbox.checked) {
            hiddenStatus.value = '1';
        } else {
            hiddenStatus.value = '0';
        }
        console.log('Status:', hiddenStatus.value);
    });
});
