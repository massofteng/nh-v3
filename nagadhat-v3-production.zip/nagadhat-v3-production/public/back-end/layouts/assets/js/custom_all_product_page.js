
    $('.bulk-product-select').select2({
        minimumResultsForSearch: Infinity
    });

    $("#category-select").select2({
        minimumResultsForSearch: Infinity
    });

    $("#product-type-select").select2({
        minimumResultsForSearch: Infinity
    });

    $("#stock-product-select").select2({
        minimumResultsForSearch: Infinity
    });


