/*---------- Product Variation function -----------**/
function ProductVariantType() {
    let productType = document.getElementById("product_type");
    let productVariation = document.getElementById("product_variation");
    let singleProduct = document.getElementById("single_product_variation");
    let offerDiscount = document.getElementById("p-offer-discount-box");
    let afterVariantSelect = document.querySelector('.after_variant_select_box');

    afterVariantSelect.style.display = 'none';
    productVariation.style.display = "none";
    singleProduct.style.display = "block";
    offerDiscount.style.display = "block";


    if (productType.value === "variants") {
        productVariation.style.display = "block";
        singleProduct.style.display = "none";
        offerDiscount.style.display = "none";
    } else if (productType.value === "single") {
        productVariation.style.display = "none";
        singleProduct.style.display = "block";
        offerDiscount.style.display = "block";
    } else {
        productVariation.style.display = "none";
        singleProduct.style.display = "none";
        offerDiscount.style.display = "none";
    }
}

/*---------- Affiliate Commission -----------**/

document.addEventListener("DOMContentLoaded", function() {
    function toggleCommissionManuallySection() {
        var affiliateCommissionManually = document.querySelector(".affiliate-commission-manually");
        var manualAffiliateRadio = document.getElementById("menual_affiliate");

        if (manualAffiliateRadio.checked) {
            affiliateCommissionManually.style.display = "block";
        } else {
            affiliateCommissionManually.style.display = "none";
        }
    }

    toggleCommissionManuallySection();

    var radioButtons = document.querySelectorAll('input[type="radio"][name="affiliate_commission"]');
    radioButtons.forEach(function(radioButton) {
        radioButton.addEventListener("change", toggleCommissionManuallySection);
    });
});



function generateProductVariantType() {
    let selectBox = document.getElementById("generate_product_variant_type");

}
function variantionMainFunction() {
    let afterVariantSelect = document.querySelector('.after_variant_select_box');
    let variationAddWeight = document.querySelector('.product_variation_item_weight');
    let variationAddColor = document.querySelector('.product_variation_item_color');
    let variationAddSize = document.querySelector('.product_variation_item_size');

    variationAddWeight.style.display = 'none';
    variationAddColor.style.display = 'none';
    variationAddSize.style.display = 'none';
    afterVariantSelect.style.display = 'block';

}





