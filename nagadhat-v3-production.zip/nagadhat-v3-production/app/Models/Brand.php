<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Brand extends Model
{
    use HasFactory;
    protected $guarded = [];

    public static function saveBrand($data, $imageLogo, $imageBanner){
        Brand::create([
            'title' => $data["title"],
            'description' => $data["description"],
            'slug' => uniqid(),
            'logo' => $imageLogo,
            'banner' => $imageBanner,
            'status' => $data["status"],
        ]);
    }
}
