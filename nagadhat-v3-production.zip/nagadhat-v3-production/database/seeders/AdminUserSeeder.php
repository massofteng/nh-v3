<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $user = User::create([
            'user_name' => 'admin3345@nagadhat',
            'name' => 'Admin',
            'email' => 'adminnagadhat@mail.com',
            'password' => bcrypt('admin1100@nagadhat'),
            'user_type' => 1,
        ]);
    }
}
