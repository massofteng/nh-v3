<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('user_name', 50)->unique(); 
            $table->string('password');
            $table->string('name', 50);
            $table->string('email', 50)->unique();
            $table->string('phone', 20)->nullable();
            $table->string('address', 200)->nullable();
            $table->string('gender', 20)->nullable();
            $table->string('first_name')->nullable();
            $table->integer('home_default_address')->nullable();
            $table->string('default_phone_number', 20)->nullable();
            $table->string('marital_status', 50)->nullable();
            $table->date('marriage_anniversary')->nullable();
            $table->integer('num_of_children')->nullable();
            $table->longText('profile_picture')->nullable();
            $table->longText('nid_front')->nullable();
            $table->longText('nid_back')->nullable();
            $table->string('date_of_birth')->nullable();
            $table->string('nid_no')->nullable();
            $table->string('nominee_name', 100)->nullable();
            $table->string('nominee_phone', 100)->nullable();
            $table->string('nominee_nid', 100)->nullable();
            $table->string('nominee_relation', 100)->nullable();
            $table->integer('affiliate_id')->nullable();
            $table->integer('referrer_id')->nullable();
            $table->double('cash_balance')->nullable();
            $table->double('shopping_balance')->nullable();
            $table->integer('user_type')->default(3)->comment("super_admin=1 admin=2,agent=3,customer=4,outlet=5,marchent=6,delivery=7");
            $table->string('unique_key')->nullable();
            $table->tinyInteger('is_sponsor_confirmed')->default(0)->comment('notconfirmed=0, confirmed=1');
            $table->tinyInteger('status')->default(1);
            $table->timestamp('email_verified_at')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
